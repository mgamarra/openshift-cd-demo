# Descrição

Esta projeto reúne o código para criação de Pipeline no Jenkins, e arquivos de suporte para implementação do CICD (Integração Contínua e Entrega Contínua) do Banco da Amazônia

# Fluxos de Pipeline

O código-fonte dos pipelines e arquivos de suporte podem ser encontrados na pasta [pipelines](pipelines) do projeto

### Amazônia Framework

- Localização do Jenkinsfile: [Jenkinsfile](pipelines/amazonia-framework-web/Jenkinsfile)
- Arquivo para importação do template pipeline para o Openshift: [amzfw-pipeline.yml](pipelines/amazonia-framework-web/amzfw-pipeline.yml)
    - Para importar no OpenShift: ```oc create -f amzfw-pipeline.yml -n cicd-jenkins```

### Aplicações JBoss

- Localização do Jenkinsfile: [Jenkinsfile](pipelines/java/Jenkinsfile)
- Arquivo para importação do template pipeline para o Openshift: [java-pipeline.yml](pipelines/java/java-pipeline.yml)
    - Para importar no OpenShift: ```oc create -f java-pipeline.yml -n cicd-jenkins```